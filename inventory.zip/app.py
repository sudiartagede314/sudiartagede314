# This project was developed inspired by the Finance problem set from Week 9
import os

from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required, time_now, local_time

# Configure application
app = Flask(__name__)

# Custom filter from personal touch pset Finance (Week 9)
app.jinja_env.filters["local_time"] = local_time

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///inventory.db")


@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


@app.route("/")
@login_required
def index():
    """Dashboard"""
    return render_template("index.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 400)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 400)

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = ?",
                          request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 400)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")

# Logout from cs50 pset Finance


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")


@app.route("/reset", methods=["GET", "POST"])
def reset():
    """Reset password user"""

    # Forget user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Get form data
        username = request.form.get("username")

        # Ensure username was submitted
        if not username:
            return apology("must provide username", 400)

        # Ensure username was admin
        if username != "admin":
            return apology("invalid username", 400)

        # Query database for username
        rows = db.execute("SELECT * FROM users")

        # Default password
        password = "admin"

        # Create admin data when there is no record yet
        if len(rows) != 1:
            db.execute(
                "INSERT INTO users (username, hash) VALUES(?, ?)", username, generate_password_hash(password))
        # Update to default password
        else:
            db.execute(
                "UPDATE users SET hash = ? WHERE id = ?", generate_password_hash(password), username)

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("reset.html")


@app.route("/item")
@login_required
def item():
    """Item management index"""

    # Database query for items
    items = db.execute("SELECT * FROM items")

    return render_template("item/index.html", items=items)


@app.route("/item_add", methods=["GET", "POST"])
@login_required
def item_add():
    """Allow user to add data of Item"""

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Get form data
        name = request.form.get("iname")
        description = request.form.get("idescription")
        quantity = request.form.get("iquantity")
        condition = request.form.get("icondition")
        location = request.form.get("ilocation")

        # Insert data into database
        db.execute(
            "INSERT INTO items (name, description, quantity, condition, location) VALUES(?, ?, ?, ?, ?)", name, description, quantity, condition, location)

        # Show flash message
        flash("The data was successfully added!")

        # Redirect user to item index
        return redirect("/item")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("item/add.html")


@app.route("/item_edit/<int:id>", methods=["GET", "POST"])
@login_required
def item_edit(id):
    """Allow user to edit data of Item"""

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Get form data
        name = request.form.get("iname")
        description = request.form.get("idescription")
        quantity = request.form.get("iquantity")
        condition = request.form.get("icondition")
        location = request.form.get("ilocation")

        # Insert data into database
        db.execute(
            "UPDATE items SET name = ?, description = ?, quantity = ?, condition = ?, location  = ? WHERE id = ?", name, description, quantity, condition, location, id)

        # Show flash message
        flash("The data was successfully updated!")

        # Redirect user to item index
        return redirect("/item")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        # Query for item data by id
        item = db.execute("SELECT * FROM items WHERE id = ?", id)[0]

        # Show edit form
        return render_template("item/edit.html", item=item)


@app.route("/item_delete/<int:id>")
def delete(id):
    """Allow user to delete item data"""

    # Delete data from database
    db.execute("DELETE FROM items WHERE id = ?", id)

    # Show flash message
    flash("The data was successfully deleted!")

    # Redirect user to item index
    return redirect("/item")


@app.route("/transaction")
@login_required
def transaction():
    """Transcation (return-borrow) management index"""

    # Database query for items
    transactions = db.execute(
        "SELECT transactions.*, borrowers.name AS borrower_name, items.id AS id_item, items.name AS item_name, details.condition_borrow, details.condition_return FROM transactions JOIN borrowers ON transactions.id_borrower = borrowers.id JOIN details ON transactions.id = details.id_transaction JOIN items ON details.id_item = items.id ORDER BY transactions.id DESC, items.id")

    return render_template("transaction/index.html", transactions=transactions)


@app.route("/transaction_add", methods=["GET", "POST"])
@login_required
def transaction_add():
    """Allow user to add data of Transaction"""

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Get form data
        id_borrower = request.form.get("bid")
        id_items = request.form.getlist("iid[]")

        # Insert transaction data into database
        id_transaction = db.execute(
            "INSERT INTO transactions (id_borrower) VALUES(?)", id_borrower)

        # Ensure one borrower are able to borrow only one item each
        quantity = 1;

        # Insert details data into database
        for id_item in id_items:
            condition_borrow = db.execute("SELECT condition FROM items WHERE id = ?", id_item)[0]["condition"]
            db.execute(
            "INSERT INTO details (id_transaction, id_item, quantity, condition_borrow) VALUES(?, ?, ?, ?)", id_transaction, id_item, quantity, condition_borrow)

            # Update items quantity
            db.execute("UPDATE items SET quantity = quantity - 1 WHERE id = ?", id_item)

        # Show flash message
        flash("The data was successfully added!")

        # Redirect user to item index
        return redirect("/transaction")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        # Query for borrowers data
        borrowers = db.execute("SELECT * FROM borrowers")

        # Query for items data
        items = db.execute("SELECT * FROM items WHERE quantity > 0")

        # Show add transaction form
        return render_template("transaction/add.html", borrowers=borrowers, items=items)

@app.route("/transaction_return/<int:id_transaction>/<int:id_item>")
def transaction_return(id_transaction, id_item):
    """Allow user to return item"""
    # Get form data
    condition = request.args.get("condition")

    # Update details (condition_return)
    db.execute("UPDATE details SET condition_return = ? WHERE id_transaction = ? AND id_item = ?", condition, id_transaction, id_item)

    # Update transactions (time_return)
    db.execute("UPDATE transactions SET time_return = ? WHERE id = ?", time_now(), id_transaction)

    # Update items quantity
    db.execute("UPDATE items SET quantity = quantity + 1 WHERE id = ?", id_item)

    # Show flash message
    flash("The item was successfully returned!")

    # Redirect user to item index
    return redirect("/transaction")

@app.route("/transaction_edit/<int:id_transaction>/<int:id_item>", methods=["GET", "POST"])
@login_required
def transaction_edit(id_transaction, id_item):
    """Allow user to edit dtransaction data"""

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Get form data
        id_borrower = request.form.get("bid")
        id_item_new = request.form.get("iid")

        # Insert data into database
        db.execute(
            "UPDATE details SET id_borrower = ?, id_item = ? WHERE id_transaction = ? AND id_item =?", id_borrower, id_item_new, id_transaction, id_item)

        # Show flash message
        flash("The data was successfully updated!")

        # Redirect user to item index
        return redirect("/transactions")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        # Query for details data by id_transaction and id_item
        detail = db.execute("SELECT b.name AS borrower_name, i.name AS item_name FROM details d WHERE id_transaction = ? JOIN borrowers b WHERE d.id_borrower = b.id JOIN items i WHERE d.id_item = i.id", id_transaction)[0]

        # Show edit form
        return render_template("/transaction/edit.html", detail=detail)

@app.route("/transaction_delete/<int:id_transaction>/<int:id_item>")
def transaction_delete(id_transaction, id_item):
    """Allow user to delete transaction data"""

    # Delete data from database
    db.execute("DELETE FROM details WHERE id_transaction = ? AND id_item = ?", id_transaction, id_item)

    # Query to Check the remain transaction details
    details = db.execute("SELECT * FROM details WHERE id_transaction = ?", id_transaction)

    # If no details remain, delete transaction
    if not details:
        db.execute("DELETE FROM transactions WHERE id_transaction = ?", id_transaction)

    # Show flash message
    flash("The data was successfully deleted!")

    # Redirect user to item index
    return redirect("/transactions")

@app.route("/borrower")
@login_required
def borrower():
    """borrower management index"""

    # Database query for items
    borrowers = db.execute("SELECT * FROM borrowers")

    return render_template("borrower/index.html", borrowers=borrowers)


@app.route("/borrower_add", methods=["GET", "POST"])
@login_required
def borrower_add():
    """Allow user to add data of borrower"""

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Get form data
        name = request.form.get("iname")
        phone = request.form.get("iphone")
        description = request.form.get("idescription")


        # Insert data into database
        db.execute(
            "INSERT INTO items (name, phone, description) VALUES(?, ?, ?)", name, phone, description)

        # Show flash message
        flash("The data was successfully added!")

        # Redirect user to item index
        return redirect("/item")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("borrower/add.html")


@app.route("/borrower_edit/<int:id>", methods=["GET", "POST"])
@login_required
def borrower_edit(id):
    """Allow user to edit data of borrower"""

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Get form data
        name = request.form.get("iname")
        phone = request.form.get("iphone")
        description = request.form.get("idescription")

        # Insert data into database
        db.execute(
            "UPDATE borrowers SET name = ?, phone = ?, description = ? WHERE id = ?", name, phone, description, id)

        # Show flash message
        flash("The data was successfully updated!")

        # Redirect user to item index
        return redirect("/borrower")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        # Query for borrower data by id
        borrower = db.execute("SELECT * FROM borrowers WHERE id = ?", id)[0]

        # Show edit form
        return render_template("borrower/edit.html", borrower=borrower)


@app.route("/borrower_delete/<int:id>")
def delete(id):
    """Allow user to delete borrower data"""

    # Delete data from database
    db.execute("DELETE FROM borrowers WHERE id = ?", id)

    # Show flash message
    flash("The data was successfully deleted!")

    # Redirect user to item index
    return redirect("/borrower")
