# This project was developed inspired by the Finance problem set from Week 9
import csv
import datetime
import pytz
import requests
import subprocess
import urllib
import uuid

from flask import redirect, render_template, session
from functools import wraps


def apology(message, code=400):
    """Render message as an apology to user."""

    def escape(s):
        """
        Escape special characters.

        https://github.com/jacebrowning/memegen#special-characters
        """
        for old, new in [
            ("-", "--"),
            (" ", "-"),
            ("_", "__"),
            ("?", "~q"),
            ("%", "~p"),
            ("#", "~h"),
            ("/", "~s"),
            ('"', "''"),
        ]:
            s = s.replace(old, new)
        return s

    return render_template("apology.html", top=code, bottom=escape(message)), code


def login_required(f):
    """
    Decorate routes to require login.

    http://flask.pocoo.org/docs/0.12/patterns/viewdecorators/
    """

    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get("user_id") is None:
            return redirect("/login")
        return f(*args, **kwargs)

    return decorated_function

# Get from personal touch pset Finance (Week 9)
def local_time(value):
    """Convert timestamp from database into local time"""
    if not value:
        return
    else:
        # str format from database into python datetime format, inspired by cs50.ai
        timestamp = datetime.datetime.fromisoformat(str(value))

        # return local time, inspired by cs50.ai
        return timestamp.replace(tzinfo=pytz.UTC).astimezone()

def time_now():
    return datetime.datetime.now()
